package com.ar.reclamo.datos;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ar.reclamo.negocio.modelo.Unidad;

@Repository
public interface UnidadRepository extends JpaRepository<Unidad, Long> {
 
	Optional<Unidad> findById(Long id);

}
