package com.ar.reclamo.negocio.exceptions;

public class UnidadException extends Exception {

	private static final long serialVersionUID = -1690698840733203643L;

	public UnidadException(String mensaje) {
		super(mensaje);
	}
}
