package com.ar.reclamo.datos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ar.reclamo.negocio.modelo.Persona; 


@Repository
public interface PersonaRepository extends JpaRepository<Persona, Long> {
    // Puedes agregar métodos personalizados si es necesario
}
