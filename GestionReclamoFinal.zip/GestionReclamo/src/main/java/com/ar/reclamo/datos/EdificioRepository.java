package com.ar.reclamo.datos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ar.reclamo.negocio.modelo.Edificio;

public interface EdificioRepository extends JpaRepository <Edificio, Long> {
	

}
