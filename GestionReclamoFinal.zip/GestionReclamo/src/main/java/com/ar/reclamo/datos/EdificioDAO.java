package com.ar.reclamo.datos;

import java.util.Optional;
import com.ar.reclamo.negocio.modelo.*;

public class EdificioDAO {

    private static EdificioDAO instancia;

    private final EdificioRepository edificioRepository;

    private EdificioDAO(EdificioRepository edificioRepository) {
        this.edificioRepository = edificioRepository;
    }

    public static EdificioDAO getInstancia(EdificioRepository edificioRepository) {
        if (instancia == null) {
            instancia = new EdificioDAO(edificioRepository);
        }
        return instancia;
    }

    public Optional<Edificio> getEdificioById(Long id) {
        return edificioRepository.findById(id);
    }

    // Otros métodos si es necesario
}