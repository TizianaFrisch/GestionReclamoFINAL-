package com.ar.reclamo.datos;


import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ar.reclamo.datos.ImagenRepository;
import com.ar.reclamo.negocio.modelo.Imagen;

@Component
public class ImagenDAO {

    private static ImagenDAO instancia;

    private final ImagenRepository imagenRepository;

    @Autowired
    public ImagenDAO(ImagenRepository imagenRepository) {
        this.imagenRepository = imagenRepository;
    }

    public static ImagenDAO getInstancia(ImagenRepository imagenRepository) {
        if (instancia == null) {
            instancia = new ImagenDAO(imagenRepository);
        }
        return instancia;
    }

    public Optional<Imagen> getImagenById(Long id) {
        return imagenRepository.findById(id);
    }

    public Imagen save(Imagen imagen) {
        return imagenRepository.save(imagen);
    }

    // Otros métodos según sea necesario
}

