package com.ar.reclamo.negocio.modelo;

public class TipoReclamo {

}
