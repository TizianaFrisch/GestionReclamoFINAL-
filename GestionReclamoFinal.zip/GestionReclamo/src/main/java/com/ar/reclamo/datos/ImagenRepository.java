package com.ar.reclamo.datos;

import java.util.Optional;

import com.ar.reclamo.negocio.modelo.Imagen;

public interface ImagenRepository {

	Optional<Imagen> findById(Long id);

	Imagen save(Imagen imagen);

}
