package com.ar.reclamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionReclamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionReclamoApplication.class, args);
	}

}
