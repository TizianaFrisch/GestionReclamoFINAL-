package com.ar.reclamo.datos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ar.reclamo.negocio.modelo.Reclamo ;


@Repository
public interface ReclamoRepository extends JpaRepository<Reclamo, Long> {
    // Puedes agregar métodos personalizados si es necesario
}