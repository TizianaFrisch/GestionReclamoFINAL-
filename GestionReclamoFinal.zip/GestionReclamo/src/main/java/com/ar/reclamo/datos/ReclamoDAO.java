package com.ar.reclamo.datos;

import java.util.Optional;
import com.ar.reclamo.negocio.modelo.*;


public class ReclamoDAO {

    private static ReclamoDAO instancia;

    private final ReclamoRepository reclamoRepository;

    private ReclamoDAO(ReclamoRepository reclamoRepository) {
        this.reclamoRepository = reclamoRepository;
    }

    public static ReclamoDAO getInstancia(ReclamoRepository reclamoRepository) {
        if (instancia == null) {
            instancia = new ReclamoDAO(reclamoRepository);
        }
        return instancia;
    }

    public Optional<Reclamo> getReclamoById(Long id) {
        return reclamoRepository.findById(id);
    }

    // Otros métodos si es necesario
}
