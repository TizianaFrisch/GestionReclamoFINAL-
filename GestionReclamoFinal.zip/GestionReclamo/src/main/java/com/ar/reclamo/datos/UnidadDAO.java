package com.ar.reclamo.datos;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ar.reclamo.datos.UnidadRepository;
import com.ar.reclamo.negocio.modelo.Unidad;

@Component
public class UnidadDAO {

    private static UnidadDAO instancia;

    private final UnidadRepository unidadRepository;

    @Autowired
    public UnidadDAO(UnidadRepository unidadRepository) {
        this.unidadRepository = unidadRepository;
    }

    public static UnidadDAO getInstancia(UnidadRepository unidadRepository) {
        if (instancia == null) {
            instancia = new UnidadDAO(unidadRepository);
        }
        return instancia;
    }

    public Optional<Unidad> getUnidadById(Long id) {
        return unidadRepository.findById(id);
    }

    public Unidad save(Unidad unidad) {
        return unidadRepository.save(unidad);
    }

    // Otros métodos según sea necesario
}