package com.ar.reclamo.datos;


import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ar.reclamo.negocio.modelo.Persona;
import com.ar.reclamo.datos.PersonaRepository;

@Component
public class PersonaDAO {

    private static PersonaDAO instancia;

    private final PersonaRepository personaRepository;

    @Autowired
    public PersonaDAO(PersonaRepository personaRepository) {
        this.personaRepository = personaRepository;
    }

    public static PersonaDAO getInstancia(PersonaRepository personaRepository) {
        if (instancia == null) {
            instancia = new PersonaDAO(personaRepository);
        }
        return instancia;
    }

    public Optional<Persona> getPersonaById(Long id) {
        return personaRepository.findById(id);
    }

    public Persona save(Persona persona) {
        return personaRepository.save(persona);
    }

    // Otros métodos según sea necesario
}

